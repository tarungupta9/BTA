package com.example.tarungupta.brainteaser;

import android.os.CountDownTimer;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;

public class MainActivity extends AppCompatActivity {

    Button startButton;
    Button firstButton;
    Button secondButton;
    Button thirdButton;
    Button fourthButton;
    Button playAgainButton;

    TextView sumTextView;
    TextView resultTextView;
    TextView scoreTextView;
    TextView timeTextView;
    TextView finalScoreTextView;

    int correctOption;
    int locationOfCorrectAnswer;
    int score = 0;
    int numberOfQuestions = 0;
    Boolean playAgain = true;

    ConstraintLayout gameConstraintLayout;

    ArrayList<Integer> answers = new ArrayList<Integer>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startButton = (Button) findViewById(R.id.startButton);
        sumTextView = (TextView) findViewById(R.id.sumTextView);
        firstButton = (Button) findViewById(R.id.firstbutton);
        secondButton = (Button) findViewById(R.id.secondbutton);
        thirdButton = (Button) findViewById(R.id.thirdbutton);
        fourthButton = (Button) findViewById(R.id.fourthbutton);
        resultTextView = (TextView) findViewById(R.id.resultTextView);
        scoreTextView = (TextView) findViewById(R.id.scoreTextView);
        timeTextView = (TextView) findViewById(R.id.timeTextView);
        finalScoreTextView = (TextView) findViewById(R.id.finalScoreTextView);
        playAgainButton = (Button) findViewById(R.id.playAgainButton);
        gameConstraintLayout = (ConstraintLayout) findViewById(R.id.gameConstraintLayout);

    }
    public void start(View view){
        startButton.setVisibility(View.INVISIBLE);
        gameConstraintLayout.setVisibility(View.VISIBLE);
        playAgain(findViewById(R.id.playAgainButton));
    }
    public void chooseAnswer(View view) {

        if (playAgain) {

            if (view.getTag().toString().equals(Integer.toString(locationOfCorrectAnswer))) {
                score++;
                resultTextView.setText("Correct!");
            } else {
                resultTextView.setText("Incorrect!");
            }
            numberOfQuestions++;
            scoreTextView.setText(Integer.toString(score) + "/" + Integer.toString(numberOfQuestions));
            generateQuestion();
        }
    }
    public void generateQuestion(){
        Random rand = new Random();
        int a = rand.nextInt(21);
        int b = rand.nextInt(21);
        int correctAnswer;
        sumTextView.setText(String.valueOf(a) + " + " + String.valueOf(b));
        answers.clear();
        correctAnswer = a + b;
        locationOfCorrectAnswer = rand.nextInt(4);
        int incorrectAnswer;

        for(int i = 0;i<4;i++){
            if(locationOfCorrectAnswer == i){
                answers.add(correctAnswer);
            }
            else{
                incorrectAnswer = rand.nextInt(41);
                while(incorrectAnswer == correctAnswer){
                    incorrectAnswer = rand.nextInt(41);
                }
                answers.add(incorrectAnswer);
            }
        }

        firstButton.setText(Integer.toString(answers.get(0)));
        secondButton.setText(Integer.toString(answers.get(1)));
        thirdButton.setText(Integer.toString(answers.get(2)));
        fourthButton.setText(Integer.toString(answers.get(3)));
    }
    public void playAgain(View view){
        score = 0;
        numberOfQuestions = 0;
        timeTextView.setText("30s");
        resultTextView.setText("");
        scoreTextView.setText("0/0");
        playAgain = true;
        playAgainButton.setVisibility(View.INVISIBLE);
        resultTextView.setVisibility(View.VISIBLE);
        finalScoreTextView.setVisibility(View.INVISIBLE);

        generateQuestion();
        new CountDownTimer(30100,1000){

            @Override
            public void onTick(long l) {
                int timeRemain = (int) l/1000;
                if(timeRemain<10){

                    timeTextView.setText("0" + timeRemain + "s");
                }
                else{
                    timeTextView.setText(String.valueOf(timeRemain) + "s");
                }
            }
            @Override
            public void onFinish() {
                playAgain = false;
                resultTextView.setVisibility(View.INVISIBLE);
                playAgainButton.setVisibility(View.VISIBLE);
                finalScoreTextView.setVisibility(View.VISIBLE);
                finalScoreTextView.setText("Your score is: " + scoreTextView.getText());
            }
        }.start();
    }
}
